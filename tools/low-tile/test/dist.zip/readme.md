pip install ray
pip install numpy
<!-- conda install -c conda-forge gdal -->
pip install rio-cogeo