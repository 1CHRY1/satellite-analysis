export interface polygonGeometry {
    type: 'Polygon'
    coordinates: number[][][]
}
