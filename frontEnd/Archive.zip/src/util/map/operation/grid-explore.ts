import { mapManager } from '../mapManager'
import { ezStore } from '@/store'
import type { GridData } from '@/type/interactive-explore/grid'


/**
 * 0. 公用函数/初始化等
 */
function uid() {
    return Math.random().toString(36).substring(2, 15)
}

/**
 * 1. 格网探查 - 格网可视化
 */
export function map_addGridDEMLayer(
    gridInfo: GridData,
    url: string,
    cb?: () => void,
) {
    const prefix = gridInfo.rowId + '_' + gridInfo.columnId
    const id = prefix + uid()
    const srcId = id + '-source'

    if (!ezStore.get('grid-dem-layer-map')) {
        ezStore.set('grid-dem-layer-map', new window.Map())
    }

    map_destroyGridDEMLayer(gridInfo)

    mapManager.withMap((m) => {
        const gridDEMLayerMap = ezStore.get('grid-dem-layer-map')
        for (let key of gridDEMLayerMap.keys()) {
            if (key.includes(prefix)) {
                const oldId = key
                const oldSrcId = oldId + '-source'
                if (m.getLayer(oldId) && m.getSource(oldSrcId)) {
                    m.removeLayer(oldId)
                    m.removeSource(oldSrcId)
                    m.setTerrain(null)
                }
            }
        }

        m.addSource(srcId, {
            type: 'raster-dem',
            tiles: [url],
            tileSize: 256,
        })
        m.setTerrain({ source: srcId, exaggeration: 4.0 })
        setTimeout(() => {
            cb && cb()
        }, 5000)
    })
}
export function map_destroyGridDEMLayer(gridInfo: GridData) {
    const prefix = gridInfo.rowId + '_' + gridInfo.columnId
    const gridDEMLayerMap = ezStore.get('grid-dem-layer-map')
    mapManager.withMap((m) => {
        m.setTerrain(null)  
        for (let key of gridDEMLayerMap.keys()) {
            if (key.includes(prefix)) { 
                const oldId = key
                const oldSrcId = oldId + '-source'
                if (m.getLayer(oldId) && m.getSource(oldSrcId)) {
                    m.removeLayer(oldId)
                    m.removeSource(oldSrcId)
                    m.setTerrain(null)  
                }
            }
        }
    })
}

export function map_addGridSceneLayer(
    gridInfo: GridData,
    url: string,
    cb?: () => void,
) {
    return map_addGrid3DLayer(gridInfo, url, cb)
}

export function map_destroyGridSceneLayer(gridInfo: GridData) {
    return map_destroyGrid3DLayer(gridInfo)
}

export function map_addGrid3DLayer(
    gridInfo: GridData,
    url: string,
    cb?: () => void,
) {
    const prefix = gridInfo.rowId + '_' + gridInfo.columnId
    const id = prefix + uid()
    const srcId = id + '-source'

    if (!ezStore.get('grid-image-layer-map')) {
        ezStore.set('grid-image-layer-map', new window.Map())
    }

    mapManager.withMap((m) => {
        const gridImageLayerMap = ezStore.get('grid-image-layer-map')
        for (let key of gridImageLayerMap.keys()) {
            if (key.includes(prefix)) {
                const oldId = key
                const oldSrcId = oldId + '-source'
                if (m.getLayer(oldId) && m.getSource(oldSrcId)) {
                    m.removeLayer(oldId)
                    m.removeSource(oldSrcId)
                }
            }
        }

        m.addSource(srcId, {
            type: 'raster',
            tiles: [url],
        })
        m.addLayer({
            id: id,
            type: 'raster',
            source: srcId,
            paint: {
                'raster-opacity': (100 - (gridInfo.opacity || 0))*0.01   // 设置透明度，值范围 0-1
            }
        })

        gridImageLayerMap.set(id, {
            id: id,
            source: srcId,
        })

        setTimeout(() => {
            cb && cb()
        }, 3000)
    })
}
export function map_destroyGrid3DLayer(gridInfo: GridData) {
    const prefix = gridInfo.rowId + '_' + gridInfo.columnId
    const gridImageLayerMap = ezStore.get('grid-image-layer-map')

    mapManager.withMap((m) => {
        for (let key of gridImageLayerMap.keys()) {
            if (key.startsWith(prefix)) {
                const oldId = key
                const oldSrcId = oldId + '-source'
                if (m.getLayer(oldId) && m.getSource(oldSrcId)) {
                    m.removeLayer(oldId)
                    m.removeSource(oldSrcId)
                }
            }
        }
    })
}

export function map_addGridNDVIOrSVRLayer(
    gridInfo: GridData,
    url: string,
    cb?: () => void,
) {
    const prefix = gridInfo.rowId + '_' + gridInfo.columnId
    const id = prefix + uid()
    const srcId = id + '-source'
    console.log(prefix)

    if (!ezStore.get('grid-oneband-layer-map')) {
        ezStore.set('grid-oneband-layer-map', new window.Map())
    }

    map_destroyGridNDVIOrSVRLayer(gridInfo)

    mapManager.withMap((m) => {
        const gridOneBandLayerMap = ezStore.get('grid-oneband-layer-map')
        for (let key of gridOneBandLayerMap.keys()) {
            if (key.includes(prefix)) {
                const oldId = key
                const oldSrcId = oldId + '-source'
                if (m.getLayer(oldId) && m.getSource(oldSrcId)) {
                    m.removeLayer(oldId)
                    m.removeSource(oldSrcId)
                }
            }
        }
        

        m.addSource(srcId, {
            type: 'raster',
            tiles: [url],
        })

        m.addLayer({
            id: id,
            type: 'raster',
            source: srcId,
            paint: {
                'raster-opacity': (100 - (gridInfo.opacity || 0))*0.01   // 设置透明度，值范围 0-1
            }
        })
        gridOneBandLayerMap.set(id, {
            id: id,
            source: srcId,
        })

        setTimeout(() => {
            cb && cb()
        }, 3000)
    })
}

export function map_destroyGridNDVIOrSVRLayer(gridInfo: GridData) {
    const prefix = gridInfo.rowId + '_' + gridInfo.columnId
    const gridOneBandLayerMap = ezStore.get('grid-oneband-layer-map')

    mapManager.withMap((m) => {
        for (let key of gridOneBandLayerMap.keys()) {
            if (key.startsWith(prefix)) {
                const oldId = key
                const oldSrcId = oldId + '-source'
                if (m.getLayer(oldId) && m.getSource(oldSrcId)) {
                    m.removeLayer(oldId)
                    m.removeSource(oldSrcId)
                }
            }
        }
    })
}

export function map_addGridMVTLayer(source_layer: string, url: string, color: string, type?: number, cb?: () => void) {
    const prefix = `GridMVT-${type || 0}`
    let layeridStore: any = null
    if (!ezStore.get('GridMVTLayerIds')) ezStore.set('GridMVTLayerIds', [])

    layeridStore = ezStore.get('GridMVTLayerIds')

    mapManager.withMap((m) => {
        const id = prefix + uid()
        const srcId = id + '-source'

        layeridStore.push(`${id}-fill`)
        layeridStore.push(`${id}-line`)
        layeridStore.push(`${id}-point`)

        m.addSource(srcId, {
            type: 'vector',
            tiles: [url],
        })

        // 添加面图层
        m.addLayer({
            id: `${id}-fill`,
            type: 'fill',
            source: srcId,
            'source-layer': source_layer,
            filter: ['==', '$type', 'Polygon'], // 只显示面要素
            paint: {
            //   'fill-color': '#0066cc',
            'fill-color': color,
            //   'fill-opacity': 0.5,
            'fill-outline-color': '#004499'
            }
        })
        
        // 添加线图层
        m.addLayer({
            id: `${id}-line`,
            type: 'line',
            source: srcId,
            'source-layer': source_layer,
            filter: ['==', '$type', 'LineString'], // 只显示线要素
            paint: {
            'line-color': color,
            'line-width': 2,
            'line-opacity': 0.8
            }
        })
        
        // 添加点图层
        m.addLayer({
            id: `${id}-point`,
            type: 'circle',
            source: srcId,
            'source-layer': source_layer,
            filter: ['==', '$type', 'Point'], // 只显示点要素
            paint: {
            'circle-color': color,
            'circle-radius': 6,
            'circle-opacity': 0.8,
            'circle-stroke-color': '#ffffff',
            'circle-stroke-width': 2
            }
        })

        setTimeout(() => {
            cb && cb()
        }, 3000)
    })
}
export function map_destroyGridMVTLayer() {
    if (!ezStore.get('GridMVTLayerIds')) return

    const layeridStore = ezStore.get('GridMVTLayerIds')
    console.log(layeridStore)
    mapManager.withMap((m) => {
        const style = m.getStyle();
        if (!style) return;
        for (let i = 0; i < layeridStore.length; i++) {
            const id = layeridStore[i]
            m.getLayer(id) && m.removeLayer(id)
            console.log(`已移除图层：${id}`)
        }
        const sources = Object.keys(style.sources || {});
        sources.forEach(sourceId => {
            if (sourceId.includes('GridMVT') && sourceId.includes('-source')) {
                m.removeSource(sourceId);
                console.log(`已移除数据源: ${sourceId}`);
            }
        });
    })
}