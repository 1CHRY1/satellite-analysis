<template>
    <div class="flex items-center space-x-4 p-4">
        <div class="simple-lines">
            <div class="line" style="--i: 1"></div>
            <div class="line" style="--i: 2"></div>
            <div class="line" style="--i: 3"></div>
            <div class="line" style="--i: 4"></div>
            <div class="line" style="--i: 5"></div>
            <div class="line" style="--i: 6"></div>
            <div class="line" style="--i: 7"></div>
            <div class="line" style="--i: 8"></div>
        </div>
    </div>
</template>

<style scoped src="./commonCom.css">

</style>