<template>
    <div class="h-full bg-sky-300">HomeView</div>
</template>

<script setup lang="ts"></script>
