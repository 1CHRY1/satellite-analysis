<template>
    <div class="h-full bg-white">LoginView</div>
</template>

<script setup lang="ts">
// import
</script>
