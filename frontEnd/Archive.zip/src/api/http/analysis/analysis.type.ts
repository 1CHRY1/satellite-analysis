//----------------------------- code online API-----------------------------//

export type analysisResponse = {
    status: number
    info: string
    projectId: string
}
